function [ output_args ] = pointlinedist( input_args )
%POINTLINEDIST Summary of this function goes here
%   Detailed explanation goes here


end

